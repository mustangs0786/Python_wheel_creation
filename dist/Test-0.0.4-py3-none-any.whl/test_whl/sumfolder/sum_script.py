def sum_two(a,b):
    result = a + b
    return result